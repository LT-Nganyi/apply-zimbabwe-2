import { IonCol, IonContent, IonHeader, IonPage, IonRow, IonTitle, IonToolbar } from '@ionic/react';
import React,{ useState } from 'react';
import { responsesAreSame } from 'workbox-broadcast-update';
import './ListContact.css';

let primaryhost:any="https://www.dmzee.co.za/"
let contact_id:any=0
let contact_type_id:any=0

const ListContact = () =>{
    const[getList, setList]     =useState<HTMLIonRowElement>()
    const callList = () =>{
        var options:any=[]
        fetch(primaryhost+"education/dbconnect/select.jsp?edu=select_contact"+
        "&contact_id="+contact_id+
        "&contact_type_id="+contact_type_id,
        {
            headers:{"content-type":"application/x-www-form-urlencoded; charset=UTF-8"}
        }
        )
        .then(response => response.json())
        .then(data => {
            console.log(data)
            options.push(data.data)
            var headers:any=(<IonRow>
                        <IonCol size = '.5'>ID</IonCol>
                        <IonCol size = '1'>Parent ID</IonCol>
                        <IonCol size = '1'>Contact Type ID</IonCol>
                        <IonCol size = '1'>Forename</IonCol>
                        <IonCol size = '1'>Surname</IonCol>
                        <IonCol size = '2.5'>Email</IonCol>
                        <IonCol size = '1'>Created Date</IonCol>
                        <IonCol size = '1'>Created By</IonCol>
                        <IonCol size = '.75'>Updated Date</IonCol>
                        <IonCol size = '.75'>Updated By</IonCol>
                        <IonCol size = '.75'>Archived Date</IonCol>
                        <IonCol size = '.75'>Archived By</IonCol>
                     </IonRow>)
            var combined:any=[]
            var list:any=options[0].map((x:any, i:number)=>{
                return(
                    <IonRow key = {i}>
                        <IonCol size = '.5'>{x.id}</IonCol>
                        <IonCol size = '1'>{x.parent_id}</IonCol>
                        <IonCol size = '1'>{x.contact_type_id}</IonCol>
                        <IonCol size = '1'>{x.forename}</IonCol>
                        <IonCol size = '1'>{x.surname}</IonCol>
                        <IonCol size = '2.5'>{x.email}</IonCol>
                        <IonCol size = '1'>{x.created_date}</IonCol>
                        <IonCol size = '1'>{x.created_by}</IonCol>
                        <IonCol size = '.75'>{x.updated_date}</IonCol>
                        <IonCol size = '.75'>{x.updated_by}</IonCol>
                        <IonCol size = '.75'>{x.archived_date}</IonCol>
                        <IonCol size = '.75'>{x.archived_by}</IonCol>


                    </IonRow>
                )
            })
            combined=[headers, list]
            setList(combined)
        })
    }
    React.useEffect(()=>{
        callList()
    },[])
    return(
        <div>
            <IonRow>
                <IonCol>Contact List</IonCol>
            </IonRow>
            
                {getList}
            
        </div>
    )
}
export default ListContact