import { IonCol, IonContent, IonHeader, IonPage, IonRow, IonTitle, IonToolbar } from '@ionic/react';
import React,{ useState } from 'react';
import { responsesAreSame } from 'workbox-broadcast-update';
let primaryhost:any="https://www.dmzee.co.za/"
let parent_id:any=0
let list_id:any=0
const ListAdmin = () =>{
    const[getList, setList]     =useState<HTMLIonRowElement>()
    const callList = () =>{
        var options:any=[]
        fetch(primaryhost+"education/dbconnect/select.jsp?edu=select_list"+
        "&parent_id="+parent_id+
        "&list_id="+list_id,
        {
            headers:{"content-type":"application/x-www-form-urlencoded; charset=UTF-8"}
        }
        )
        .then(response => response.json())
        .then(data => {
            console.log(data)
            options.push(data.data)
            var headers:any=(<IonRow>
                        <IonCol>ID</IonCol>
                        <IonCol>Description</IonCol>
                        <IonCol>CreatedBy</IonCol>
                        <IonCol>Is Archived</IonCol>
                     </IonRow>)
            var combined:any=[]
            var list:any=options[0].map((x:any, i:number)=>{
                return(
                    <IonRow key = {i}>
                        <IonCol>{x.id}</IonCol>
                        <IonCol>{x.list_desc}</IonCol>
                        <IonCol>{x.created_by}</IonCol>
                        <IonCol></IonCol>
                    </IonRow>
                )
            })
            combined=[headers, list]
            setList(combined)
        })
    }
    React.useEffect(()=>{
        callList()
    },[])
    return(
        <div>
            <IonRow>
                <IonCol>List Admin</IonCol>
            </IonRow>
            
                {getList}
            
        </div>
    )
}
export default ListAdmin